#!/usr/bin/env python3
import sys
sys.path.insert(0, 'path/to/trainme')

from .read_data import ReadFile