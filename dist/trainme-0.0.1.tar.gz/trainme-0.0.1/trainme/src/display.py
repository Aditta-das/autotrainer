from tabulate import tabulate
def Output(data):
    return tabulate([[data]])