class CFG:
    random_state = 42
    shuffle = True
    test_size = 0.3
    no_of_fold = 5
    use_gpu = False